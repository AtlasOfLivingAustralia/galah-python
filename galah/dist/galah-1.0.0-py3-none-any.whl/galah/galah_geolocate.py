def galah_geolocate():
    # pseudocode here
    n=1
